
SMODS.Joker{ --Morgana
    key = "morgana",
    config = {
        extra = {
            heartsindeck = 0
        }
    },
    loc_txt = {
        ['name'] = 'Morgana',
        ['text'] = {
            [1] = '{C:red}+2 Mult{} for each {C:hearts}Heart{} card',
            [2] = 'in your deck.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["persona5_persona5_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {localize((G.GAME.current_round.Morgana_card or {}).suit or 'Spades', 'suits_singular'), ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.suit == 'Hearts' then count = count + 1 end end; return count end)()) * 2}, colours = {G.C.SUITS[(G.GAME.current_round.Morgana_card or {}).suit or 'Spades']}}
    end,
    
    set_ability = function(self, card, initial)
        G.GAME.current_round.Morgana_card = { suit = 'Hearts' }
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
            mult = ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.suit == 'Hearts' then count = count + 1 end end; return count end)()) * 2
            }
        end
    end
}
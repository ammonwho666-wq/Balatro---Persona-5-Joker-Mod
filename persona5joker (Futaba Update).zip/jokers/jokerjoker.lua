
SMODS.Joker{ --Joker Joker
    key = "jokerjoker",
    config = {
        extra = {
            xmult0 = 2,
            xmult = 2,
            xmult2 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Joker Joker',
        ['text'] = {
            [1] = 'Each Queen played gives {C:red}x2 Mult{};',
            [2] = '{C:red}x2 Mult{} again if you have {C:uncommon}Mr. Bones{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["persona5_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 12) and (not ((function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_mr._bones" then 
                        return true
                    end
                end
            end)())) then
                return {
                    Xmult = 2
                }
            elseif (context.other_card:get_id() == 12) and ((function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_mr._bones" then 
                        return true
                    end
                end
            end)()) then
                return {
                    Xmult = 2,
                    extra = {
                        Xmult = 2
                    }
                }
            end
        end
    end
}